import React, { useState } from 'react';

export default function AddForm({ onAdd, onCancel }) {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [serial, setSerial] = useState('');
  const [acquired, setAcquired] = useState('');
  const [location, setLocation] = useState('');
  const [assignedTo, setAssignedTo] = useState('');
  const [state, setState] = useState('Disponible');
  const [notes, setNotes] = useState('');

  function submit(e) {
    e.preventDefault();
    if(!name || !category) return alert('Nombre y categoría son requeridos');
    onAdd({ name, category, serial, acquired, location, assignedTo, state, notes });
  }

  return (
    <form className="bg-white rounded shadow p-4 mb-4" onSubmit={submit}>
      <h2 className="font-semibold mb-3">Agregar nuevo equipo</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        <input placeholder="Nombre del equipo" className="p-2 border rounded" value={name} onChange={(e)=>setName(e.target.value)} />
        <input placeholder="Categoría (ej. Cámara, Laptop)" className="p-2 border rounded" value={category} onChange={(e)=>setCategory(e.target.value)} />
        <input placeholder="Número de serie" className="p-2 border rounded" value={serial} onChange={(e)=>setSerial(e.target.value)} />
        <input type="date" placeholder="Fecha de adquisición" className="p-2 border rounded" value={acquired} onChange={(e)=>setAcquired(e.target.value)} />
        <input placeholder="Ubicación" className="p-2 border rounded" value={location} onChange={(e)=>setLocation(e.target.value)} />
        <input placeholder="Asignado a" className="p-2 border rounded" value={assignedTo} onChange={(e)=>setAssignedTo(e.target.value)} />
        <select className="p-2 border rounded" value={state} onChange={(e)=>setState(e.target.value)}>
          <option>Disponible</option>
          <option>Prestado</option>
          <option>En mantenimiento</option>
          <option>Dañado</option>
        </select>
        <input placeholder="Notas" className="p-2 border rounded" value={notes} onChange={(e)=>setNotes(e.target.value)} />
      </div>
      <div className="mt-3 flex gap-2">
        <button className="px-3 py-2 bg-green-600 text-white rounded" type="submit">Agregar</button>
        <button className="px-3 py-2 bg-gray-200 rounded" type="button" onClick={onCancel}>Cancelar</button>
      </div>
    </form>
  );
}
