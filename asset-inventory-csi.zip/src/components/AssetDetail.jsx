import React, { useEffect, useState } from 'react';

export default function AssetDetail({ asset, onUpdate, onDelete, onPrint }) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ ...asset });

  useEffect(()=>setForm({...asset}), [asset]);

  function save() {
    onUpdate(form);
    setEditing(false);
  }

  return (
    <div>
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-semibold text-lg">{asset.name}</h3>
          <div className="text-xs text-gray-500">{asset.id} • {asset.category}</div>
        </div>
        <div className="space-x-2">
          <button className="px-2 py-1 bg-gray-200 rounded" onClick={()=>setEditing(!editing)}>{editing ? 'Cancelar' : 'Editar'}</button>
          <button className="px-2 py-1 bg-red-500 text-white rounded" onClick={onDelete}>Eliminar</button>
        </div>
      </div>

      {!editing ? (
        <div className="mt-3 text-sm space-y-1">
          <div>Serial: {asset.serial || '—'}</div>
          <div>Adquirido: {asset.acquired || '—'}</div>
          <div>Ubicación: {asset.location || '—'}</div>
          <div>Asignado a: {asset.assignedTo || '—'}</div>
          <div>Estado: {asset.state}</div>
          <div>Notas: {asset.notes || '—'}</div>
          <div className="mt-3"><button className="px-3 py-2 bg-indigo-600 text-white rounded" onClick={onPrint}>Imprimir etiqueta</button></div>
        </div>
      ) : (
        <div className="mt-3 grid grid-cols-1 gap-2">
          <input className="p-2 border rounded" value={form.serial} onChange={(e)=>setForm({...form, serial: e.target.value})} placeholder="Serial" />
          <input className="p-2 border rounded" value={form.location} onChange={(e)=>setForm({...form, location: e.target.value})} placeholder="Ubicación" />
          <input className="p-2 border rounded" value={form.assignedTo} onChange={(e)=>setForm({...form, assignedTo: e.target.value})} placeholder="Asignado a" />
          <select className="p-2 border rounded" value={form.state} onChange={(e)=>setForm({...form, state: e.target.value})}>
            <option>Disponible</option>
            <option>Prestado</option>
            <option>En mantenimiento</option>
            <option>Dañado</option>
          </select>
          <textarea className="p-2 border rounded" value={form.notes} onChange={(e)=>setForm({...form, notes: e.target.value})} />
          <div className="flex gap-2">
            <button className="px-3 py-2 bg-green-600 text-white rounded" onClick={save}>Guardar</button>
            <button className="px-3 py-2 bg-gray-200 rounded" onClick={()=>{ setForm({...asset}); setEditing(false); }}>Cancelar</button>
          </div>
        </div>
      )}
    </div>
  );
}
