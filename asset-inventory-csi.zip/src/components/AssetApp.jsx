import React, { useEffect, useState, useRef } from 'react';
import AddForm from './AddForm';
import AssetDetail from './AssetDetail';

const sampleAssets = [
  {
    id: 'CSI-CAM-001',
    name: 'Cámara Canon EOS M50',
    category: 'Cámara',
    serial: 'SN-233894',
    acquired: '2024-06-10',
    location: 'Estudio Multimedia',
    assignedTo: '',
    state: 'Disponible',
    notes: 'Lente 18-55mm',
  },
];

export default function AssetApp() {
  const [assets, setAssets] = useState(() => {
    try {
      const raw = localStorage.getItem('csi_assets_v1');
      return raw ? JSON.parse(raw) : sampleAssets;
    } catch (e) {
      return sampleAssets;
    }
  });
  const [view, setView] = useState('list');
  const [selectedId, setSelectedId] = useState(null);
  const [query, setQuery] = useState('');

  useEffect(() => {
    localStorage.setItem('csi_assets_v1', JSON.stringify(assets));
  }, [assets]);

  function generateId(category) {
    const prefix = `CSI-${category.slice(0,3).toUpperCase()}`;
    const same = assets.filter((a) => a.id.startsWith(prefix)).length;
    return `${prefix}-${String(same+1).padStart(3,'0')}`;
  }

  function addAsset(payload) {
    const id = generateId(payload.category);
    const asset = { id, ...payload };
    setAssets((s) => [asset, ...s]);
    setSelectedId(id);
    setView('detail');
  }

  function updateAsset(id, patch) {
    setAssets((s) => s.map((a) => (a.id === id ? { ...a, ...patch } : a)));
  }

  function removeAsset(id) {
    if (!confirm('¿Eliminar este equipo? Esta acción es irreversible.')) return;
    setAssets((s) => s.filter((a) => a.id !== id));
    setView('list');
  }

  const filtered = assets.filter((a) =>
    a.id.toLowerCase().includes(query.toLowerCase()) || a.name.toLowerCase().includes(query.toLowerCase())
  );

  const selected = assets.find((a) => a.id === selectedId);

  async function printLabel(asset) {
    const w = window.open('', '_blank', 'width=400,height=300');
    if (!w) return alert('Permite ventanas emergentes para imprimir la etiqueta.');
    const html = `
      <html><head><title>Etiqueta ${asset.id}</title>
      <style>body{font-family:Arial;padding:10px}.label{width:320px;border:1px solid #222;padding:10px}</style>
      </head><body>
      <div class="label">
        <h3>${asset.name}</h3>
        <p>ID: ${asset.id}</p>
        <div id="barcode"></div>
        <p style="font-size:12px;color:#666">Consejería de Salud Integral Inc.</p>
      </div>
      <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>
      <script>
        const svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
        document.getElementById('barcode').appendChild(svg);
        JsBarcode(svg, '${asset.id}', {format: 'CODE128', displayValue: true, fontSize:14});
      </script>
      </body></html>
    `;
    w.document.write(html);
    setTimeout(()=>w.print(),700);
  }

  return (
    <div className="max-w-6xl mx-auto">
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Asset Inventory - Prototipo</h1>
        <div className="space-x-2">
          <button className="px-3 py-2 bg-blue-600 text-white rounded" onClick={() => { setView('add'); setSelectedId(null); }}>Agregar equipo</button>
        </div>
      </header>

      <main className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <section className="md:col-span-2">
          <div className="mb-4 flex items-center gap-3">
            <input className="flex-1 p-2 border rounded" placeholder="Buscar por ID o nombre..." value={query} onChange={(e)=>setQuery(e.target.value)} />
          </div>

          {view==='add' && <AddForm onAdd={addAsset} onCancel={()=>setView('list')} />}

          {view==='list' && (
            <div className="bg-white rounded shadow p-4">
              <h2 className="font-semibold mb-3">Lista de equipos ({filtered.length})</h2>
              <div className="divide-y">
                {filtered.map((a)=>(
                  <div key={a.id} className="py-2 flex items-center justify-between">
                    <div>
                      <div className="font-medium">{a.name}</div>
                      <div className="text-sm text-gray-600">{a.id} • {a.category} • {a.location}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button className="px-2 py-1 text-sm bg-yellow-100 rounded" onClick={()=>{ setSelectedId(a.id); setView('detail'); }}>Ver</button>
                      <button className="px-2 py-1 text-sm bg-indigo-100 rounded" onClick={()=>printLabel(a)}>Imprimir etiqueta</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {view==='detail' && selected && (
            <div className="bg-white rounded shadow p-4 mt-4">
              <AssetDetail asset={selected} onUpdate={(patch)=>updateAsset(selected.id, patch)} onDelete={()=>removeAsset(selected.id)} onPrint={()=>printLabel(selected)} />
            </div>
          )}
        </section>

        <aside className="md:col-span-1">
          <div className="bg-white rounded shadow p-4 mb-4">
            <h3 className="font-semibold mb-2">Detalle rápido</h3>
            {selected ? (
              <div>
                <div className="text-sm text-gray-700">{selected.name}</div>
                <div className="text-xs text-gray-500">{selected.id}</div>
                <div className="mt-3 text-sm">Estado: <strong>{selected.state}</strong></div>
                <div className="mt-2 text-sm">Asignado: {selected.assignedTo || '—'}</div>
                <div className="mt-3"><button className="px-3 py-2 bg-indigo-600 text-white rounded" onClick={()=>printLabel(selected)}>Imprimir etiqueta</button></div>
              </div>
            ):(<div className="text-sm text-gray-500">Selecciona un equipo para ver más detalles.</div>)}
          </div>
          <div className="bg-white rounded shadow p-4">
            <h3 className="font-semibold mb-2">Acciones</h3>
            <div className="flex flex-col gap-2">
              <button className="px-3 py-2 bg-blue-600 text-white rounded" onClick={()=>{ setView('add'); setSelectedId(null); }}>Nuevo equipo</button>
              <button className="px-3 py-2 bg-gray-200 rounded" onClick={()=>{ navigator.clipboard.writeText(JSON.stringify(assets)); alert('Assets copiados al portapapeles (JSON).'); }}>Exportar (JSON)</button>
            </div>
          </div>
        </aside>
      </main>
    </div>
  );
}
