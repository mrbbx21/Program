import '../styles/globals.css';

export const metadata = {
  title: 'Asset Inventory - CSI',
  description: 'Inventario de activos con barcode',
}

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body className="min-h-screen">
        {children}
      </body>
    </html>
  )
}
