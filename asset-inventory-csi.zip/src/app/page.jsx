import dynamic from 'next/dynamic'
import Head from 'next/head'

const AssetApp = dynamic(() => import('../../components/AssetApp'), { ssr: false })

export default function Page() {
  return (
    <main className="p-6">
      <Head>
        <title>Asset Inventory - CSI</title>
      </Head>
      <AssetApp />
    </main>
  )
}
